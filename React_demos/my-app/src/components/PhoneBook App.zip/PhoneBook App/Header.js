import { useState } from "react";
import Addcontact from "./Addcontact";
import Display from "./display";
import './header.css'

export default function Header(){

    const[click,setClick]=useState(false);
    function changeState(){
       setClick(true);
    }
    
    
    return(
        <div className="main">
            <h1>Phone Book App</h1> 
            <div className="main2">
                <h2>Contacts</h2>
                <button onClick={changeState}>+ Add Contact</button>
            </div>
            <div className="searchBar">
               <input type="text" placeholder="search"></input>
            </div>
            <div className="display">
                <Display/>
            </div>
            {click && <Addcontact/>}
        </div>
        
        
    );
}