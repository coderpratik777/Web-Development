import Header from "./Header";
import './PhoneBook.css'

export default function PhoneBook(){
    return(<>
        <Header/>
    </>);
}